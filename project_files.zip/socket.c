// SOCKET
// command line takes KB input,
//
// To run this code ./a.out <size of array>
// Y1-S1/ARP/ARP1_Assigment2$ gcc socket.c -o socket
// Example: $./a.out 1000
//
// To compile & run this code for 100 MB, type following on the terminal
// gcc -Wall -o socket socket.c && ./socket 102400

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <omp.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <math.h>
#include <arpa/inet.h>
#include <memory.h>
#define PORT 8080

// https://stackoverflow.com/questions/67809204/how-to-send-and-receive-data-chunk-by-chunk-in-linux-sockets?fbclid=IwAR0tsKN8bNz9uW1VjCulSbVe0NjcYERHxUEKc4_ImPSPpk8eiCU7CdR1sDE
int send_data(int sockfd, const void *buffer, size_t bufsize)
{
    int sended = 0;
    const char *pbuffer = (const char *)buffer;
    while (bufsize > 0) // it will send the data in small pieces (buffsize) untill it complete.
    {
        int n = send(sockfd, pbuffer, bufsize, 0);
        if (n < 0)
            return -1;
        pbuffer += n; //increse the pointer.
        bufsize -= n;
        sended += n;
    }
    // printf("Total sent [bytes] =%d\n", sended);
    return 0;
}
int receive_data(int sockfd, void *buffer, size_t bufsize)
{
    char *pbuffer = (char *)buffer;
    while (bufsize > 0) // the loop do exactly the seme with send but just read the data
    {
        int n = recv(sockfd, pbuffer, bufsize, 0);
        if (n <= 0)
            return n;
        pbuffer += n;
        bufsize -= n;
    }
    return 1;
}

void error_prompt(char error_msg[], int status) //loop for checking the error val
{
    if (status < 0)
    {
        perror(error_msg);
        exit(EXIT_FAILURE);
    }
}
// https://stackoverflow.com/questions/3557221/how-do-i-measure-time-in-c/3557272
double what_time_is_it() // loo
{
    struct timespec now;
    clock_gettime(CLOCK_REALTIME, &now);
    return now.tv_sec + now.tv_nsec * 1e-9;
}

int main(int argc, char *argv[])
{
    // initiate part---------------------------------------------------
    if (argc < 2)
    {
        perror("Plese input size of array");
        exit(EXIT_FAILURE);
    }
    int res; // for error handling
    // https://stackoverflow.com/questions/19778722/segmentation-fault-and-core-dumped-when-trying-to-declare-a-big-array
    int size_of_array = atoi(argv[1]) * 1024 / sizeof(int);
    
    int *a = (int *)malloc(size_of_array * sizeof(int));
    if (a == NULL)
        error_prompt("malloc a failed", -1);
    // printf("Create A array size= %d\n", size_of_array);
    // printf("Total size in kilobytes= %d\n", atoi(argv[1]));

    int sizeofint = 4;

    // assign random number to the array
    for (int i = 0; i < size_of_array; ++i)
    {
        a[i] = rand() % 1000; // modulo by 1000 because for 0-999
        if (i < 3 || i == size_of_array / 2 || i > size_of_array - 4)
            printf("Sent Index%d is %d\n", i, a[i]);
    }

    // init the communication ---------------------------------
    // start_counting the time
    double start_time_init = what_time_is_it();

    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Forcefully attaching socket to the port 8080
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                   &opt, sizeof(opt)))
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    if (bind(server_fd, (struct sockaddr *)&address,
             sizeof(address)) < 0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    int fork_client = fork();
    error_prompt("fork failed", fork_client);
    if (fork_client == 0)
    {
        //------------------client process-------------------------------
        // printf("Child node started\n");
        res = close(server_fd);
        error_prompt("close(server_fd) failed", res);
        int sock = 0;
        struct sockaddr_in serv_addr;
        
        int *buffer = (int *)malloc(size_of_array * sizeof(int));
        if (buffer == NULL)
            error_prompt("malloc a failed", -1);
        
        if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        {
            printf("\n Socket creation error \n");
            return -1;
        }

        serv_addr.sin_family = AF_INET;
        serv_addr.sin_port = htons(PORT);

        // Convert IPv4 and IPv6 addresses from text to binary form
        if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0)
        {
            printf("\nInvalid address/ Address not supported \n");
            return -1;
        }

        if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
        {
            printf("\nConnection Failed \n");
            return -1;
        }

        receive_data(sock, buffer, size_of_array * 4);

        printf("---\n");
        printf("Received Index0 is %d\n", buffer[0]);
        printf("Received Index1 is %d\n", buffer[1]);
        printf("Received Index2 is %d\n", buffer[2]);
        printf("Received Index%d is %d\n", size_of_array / 2, buffer[size_of_array / 2]);
        printf("Received Index%d is %d\n", size_of_array - 3, buffer[size_of_array - 3]);
        printf("Received Index%d is %d\n", size_of_array - 2, buffer[size_of_array - 2]);
        printf("Received Index%d is %d\n", size_of_array - 1, buffer[size_of_array - 1]);

        free(buffer);
        return 0;
        //------------------- end of client -------------------------------
    }
    else
    {
        // printf("Parent node started\n");
        //--------------------server process-------------------------------
        // Forcefully attaching socket to the port 8080

        if (listen(server_fd, 3) < 0)
        {
            perror("listen");
            exit(EXIT_FAILURE);
        }
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address,
                                 (socklen_t *)&addrlen)) < 0)
        {
            perror("accept");
            exit(EXIT_FAILURE);
        }
        // Start sending data here ----------------------------
        double start_time_send = what_time_is_it();
        send_data(new_socket, a, size_of_array * 4);
        free(a);
        // printf("Array sent\n");
        wait(NULL);
        double finish_time = what_time_is_it();

        printf("---\n\n");
        printf("SOCKET\n\n");
        printf("User requested to transfer TOTAL OF %d KB = %d MB.\nData is transferred as integers. The size of integer is %d bytes.\n", atoi(argv[1]), atoi(argv[1]) / 1024, sizeofint);
        printf("\nSo an integer array of %d elements is created and sent successfully.\n", size_of_array);
        printf("\nTime calculated for transfers:\n");
        printf("Since the start-up of processes : %.6lf seconds, \n", finish_time - start_time_init);
        printf("Since the start-up of send      : %.6lf seconds. \n", finish_time - start_time_send);
        printf("\n---\n\n");

	res = close(server_fd); // close server
        error_prompt("close(server_fd) failed", res);
        return 0;
        //---------------------End of server code-----------------------------
    }
}

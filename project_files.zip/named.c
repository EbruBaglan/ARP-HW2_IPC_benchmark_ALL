// NAMED PIPE
// command line takes KB input,
//
// for 100 MB array, use the command line of:
// ./named 102400
//
// To compile & run this code for 100 MB, type following on the terminal 
// gcc -Wall -o named named.c && ./named 102400

#define _GNU_SOURCE
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <omp.h>
#include <memory.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h> // mkfifo

int flag = 0;

void error_prompt(char error_msg[], int status)
{
    if (status < 0)
    {
        perror(error_msg);
        exit(EXIT_FAILURE);
    }
}

double what_time_is_it()
{
    // https://stackoverflow.com/questions/3557221/how-do-i-measure-time-in-c/3557272
    struct timespec now;
    clock_gettime(CLOCK_REALTIME, &now);
    return now.tv_sec + now.tv_nsec * 1e-9;
}

void my_handler(int signum)
{
    if (signum == SIGUSR1)
    {
        flag = 1;
    }
}

int main(int argc, char *argv[])
{
    // initiate part--------
    if (argc < 2)
    {
        perror("Please enter the size of the array in KB");
        exit(EXIT_FAILURE);
    }

    int size_of_array = atoi(argv[1]) * 1024 / sizeof(int);

    int fd1, fd2;
    int sizeofint = 4;
    int ret;
    sighandler_t res;
    pid_t child_pid;

    char *myfifo = "/tmp/myfifo5";
    if ((ret = mkfifo(myfifo, 0666)) != 0)
        error_prompt("mkfifo failed", ret);

    int *a;

    if ((a = (int *)malloc(size_of_array * sizeof(int))) == NULL)
    {
        printf("malloc error \n ");
        exit(1);
    }

    // assign random number to the array
    for (int i = 0; i < size_of_array; ++i){
        a[i] = rand() % 1000;
        if (i < 3 || i == size_of_array / 2 || i > size_of_array - 4)
        {
            printf("Sent Index%d is %d\n", i, a[i]);
        }
    }

    double start_time_init = what_time_is_it();

    if ((child_pid = fork()) == -1)
        error_prompt("fork failed", child_pid);

    else if (child_pid == 0)
    {
        // child process
        if ((fd2 = open(myfifo, O_RDONLY)) < 0)
            error_prompt("fd2", fd2);

        int *buffer = (int *)malloc(size_of_array * sizeof(int));
        int n = 0;
        int remaining = size_of_array;
        int i = 0;
        while (remaining != 0)
        {
            if ((n += read(fd2, buffer + i, 65536)) < 0)
                error_prompt("read failed", n);

            i += 65536/4;

            if ((ret = kill(getppid(), SIGUSR1)) != 0)
                error_prompt("kill failed", ret);

            remaining -= 65536/4;
            if (remaining < 0)
                remaining = 0;
        }

        //printf("\nReceived, first value = %d, last value = %d\n", buffer[0], buffer[size_of_array - 1]);

        printf("---\n");
        printf("Received Index0 is %d\n", buffer[0]);
        printf("Received Index1 is %d\n", buffer[1]);
        printf("Received Index2 is %d\n", buffer[2]);
        printf("Received Index%d is %d\n", size_of_array / 2, buffer[size_of_array / 2]);
        printf("Received Index%d is %d\n", size_of_array - 3, buffer[size_of_array - 3]);
        printf("Received Index%d is %d\n", size_of_array - 2, buffer[size_of_array - 2]);
        printf("Received Index%d is %d\n", size_of_array - 1, buffer[size_of_array - 1]);

        free(buffer);

        if ((ret = close(fd2)) == -1)
            error_prompt("close fd2 failed", ret);

        return 0;
    }
    else
    {
        // parent process
        if ((fd1 = open(myfifo, O_WRONLY)) < 0)
            error_prompt("fd1", fd1);

        // printf("\nPipe size: %d bytes = %d KB\n", fcntl(fd1, F_GETPIPE_SZ), fcntl(fd1, F_GETPIPE_SZ) / 1024);

        if ((res = signal(SIGUSR1, my_handler)) == SIG_ERR)
            error_prompt("signal", ret);

        int remaining = size_of_array;

        int i = 0;

        double start_time_send = what_time_is_it();

        while (remaining != 0)
        {
            if ((ret = write(fd1, a + i, 65536)) < 0)
                error_prompt("write failed", ret);

            i += 65536/4;
            remaining -= 65536/4;

            if (remaining < 0)
                remaining = 0;

            while (flag == 0)
                pause();
            flag = 0;
        }

        free(a);

        wait(NULL);

        double finish_time = what_time_is_it();
        
        printf("---\n\n");
        printf("NAMED PIPE\n\n");
        printf("User requested to transfer TOTAL OF %d KB = %d MB with %d KB named pipe capacity.\nData is transferred as integers. The size of integer is %d bytes.\n", atoi(argv[1]), atoi(argv[1]) / 1024, fcntl(fd1, F_GETPIPE_SZ) / 1024, sizeofint);
        printf("\nSo an integer array of %d elements is created and sent successfully.\n", size_of_array);
        printf("\nTime calculated for transfers:\n");
        printf("Since the start-up of processes : %.6lf seconds, \n", finish_time - start_time_init);
        printf("Since the start-up of send      : %.6lf seconds. \n", finish_time - start_time_send);
        printf("\n---\n\n");

        if ((ret = close(fd1)) == -1)
            error_prompt("close fd2 failed", ret);

        if ((ret = unlink(myfifo)) == -1)
            error_prompt("unlink failed", ret);

        return 0;
    }
}

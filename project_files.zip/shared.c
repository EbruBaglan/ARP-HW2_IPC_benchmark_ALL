// SHARED MEMORY WITH CIRCULAR BUFFER
// command line takes KB input,
//
// for 100 MB array and 4 KB buffer, use the command line of:
// ./shared 102400 4
//
// To compile and run this code for 100 MB with 4 KB buffer, type following on the terminal
// gcc -Wall -o shared shared.c -lrt -lpthread && ./shared 102400 4

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h> // CLOCK_REAL_TIME
#include <time.h>     // CLOCK_REAL_TIME

#define CLOCK_REALTIME 0

void error_prompt(char *error_msg)
{
    perror(error_msg);
    exit(EXIT_FAILURE);
}

double what_time_is_it()
{
    // https://stackoverflow.com/questions/3557221/how-do-i-measure-time-in-c/3557272
    struct timespec now;
    clock_gettime(CLOCK_REALTIME, &now);
    return now.tv_sec + now.tv_nsec * 1e-9;
}

int main(int argc, char *argv[])
{
    // argument number should be at least 3, program name, message size and buffer size
    if (argc < 3)
    {
        perror("Please enter BOTH message size AND BUFFER CBSIZE. For instance ./shared 102400 4 \n");
        exit(EXIT_FAILURE);
    }

    // buffer size should not be higher than message size
    if (atoi(argv[2]) > atoi(argv[1]))
    {
        perror("Buffer size cannot be bigger than message size. Enter for instance ./shared 102400 4  \n");
        exit(EXIT_FAILURE);
    }

    double start_time_init = what_time_is_it();

    int MSGSIZE, CBSIZE, erre;
    int sizeofint = 4; // bytes
    int flag, counter;

    CBSIZE = atoi(argv[2]) * 1024;                  // circular buffer size, KB changed to bytes here
    int max_num_int_each_time = CBSIZE / sizeofint; // MAX number of integers used in each cycle

    MSGSIZE = atoi(argv[1]) * 1024;                         // message size, KB input changed to bytes here
    int num_int_total = MSGSIZE / sizeofint;                // how many integers used in total
    int num_cycles = num_int_total / max_num_int_each_time; // how many cycles in total

    int remainder = MSGSIZE % CBSIZE / sizeofint; // remainder in number of integers
    if (remainder != 0)
        flag = 1;

    // SEMAPHORE VARIABLES
    sem_t *sem1; // First semaphore
    sem_t *sem2; // Second semaphore

    /* name of the shared memory object */
    const char *semname1 = "/JakePeralta";
    const char *semname2 = "/AmySantiago";

    // create, initialize semaphores
    if ((sem1 = sem_open(semname1, O_CREAT, 0644, 1)) == SEM_FAILED)
        error_prompt("sem1");

    if ((sem2 = sem_open(semname2, O_CREAT, 0644, 0)) == SEM_FAILED)
        error_prompt("sem2");

    // end of SEMAPHORE VARIABLES

    int *arr1, *arr3;

    // allocating area on HEAP. Why? CUZ STACKOVERFLOW!!!!!
    if ((arr1 = malloc(sizeof(int) * num_int_total)) == NULL)
    {
        printf("arr1 malloc error\n");
        exit(1);
    }

    if ((arr3 = malloc(sizeof(int) * num_int_total)) == NULL)
    {
        printf("arr3 malloc error\n");
        exit(1);
    }

    // assigning TOTAL messages here to arr1
    for (int k = 0; k < num_int_total; k++)
    {
        arr1[k] = rand() % 1000;

        // checking first and last 3 integers and middle index to make sure
        if (k < 3 || k == num_int_total / 2 || k > num_int_total - 4)
        {
            printf("Sent Index%d is %d\n", k, arr1[k]);
        }
    }

    /* name of the shared memory object */
    const char *name = "/littlespoonalltheway";

    /* shared memory file descriptor */
    int shm_fd;

    /* pointer to shared memory object */
    int *ptr;

    /* create the shared memory object */
    if ((shm_fd = shm_open(name, O_CREAT | O_RDWR, 0666)) == -1)
        error_prompt("shm open");

    /* configure the size of the shared memory object, absence causes Bus error */
    if (ftruncate(shm_fd, CBSIZE) == -1)
        error_prompt("ftruncate");

    /* memory map the shared memory object */
    if ((ptr = mmap(0, CBSIZE, PROT_WRITE | PROT_READ, MAP_SHARED, shm_fd, 0)) == MAP_FAILED)
        error_prompt("mmap");

    pid_t child_pid = fork();

    double start_time_send = what_time_is_it();

    switch (child_pid)
    {
    case -1:
        error_prompt("fork");

    case 0:
        /* child process */

        /* arr1 is seperated to chunks of max_sendable_numbers */
        for (counter = 0; counter < num_cycles; counter++)
        {
            sem_wait(sem1); // lock the semaphore
            memcpy(ptr, arr1 + counter * max_num_int_each_time, CBSIZE);
            sem_post(sem2); // release the semaphore lock
        }
        if (flag == 1)
        {
            sem_wait(sem1); // lock the semaphore
            memcpy(ptr, arr1 + counter * max_num_int_each_time, remainder * sizeofint);
            sem_post(sem2); // release the semaphore lock
        }

        free(arr1);

        /* unmap the shared memory object */
        if (munmap(ptr, CBSIZE) != 0)
            error_prompt("munmap");

        break;

    default: // case 1 ... __INT_MAX__
        // parent process

        for (erre = 0; erre < num_cycles; erre++) //
        {
            sem_wait(sem2); // Lock the semaphore
            memcpy(arr3 + max_num_int_each_time * erre, ptr, CBSIZE);
            sem_post(sem1); // Release the semaphore lock
        }

        // once more for the last remaining items
        if (flag == 1)
        {
            sem_wait(sem2); // Lock the semaphore
            memcpy(arr3 + max_num_int_each_time * erre, ptr, remainder * sizeofint);
            sem_post(sem1); // Release the semaphore lock
        }

        printf("---\n");
        printf("Received Index0 is %d\n", arr3[0]);
        printf("Received Index1 is %d\n", arr3[1]);
        printf("Received Index2 is %d\n", arr3[2]);
        printf("Received Index%d is %d\n", num_int_total / 2, arr3[num_int_total / 2]);
        printf("Received Index%d is %d\n", num_int_total - 3, arr3[num_int_total - 3]);
        printf("Received Index%d is %d\n", num_int_total - 2, arr3[num_int_total - 2]);
        printf("Received Index%d is %d\n", num_int_total - 1, arr3[num_int_total - 1]);

        double finish_time = what_time_is_it();
        printf("---\n\n");
        printf("SHARED MEMORY WITH CIRCULAR BUFFER\n\n");
        printf("User requested to transfer TOTAL OF %d KB = %d MB with %d KB buffer.\nData is transferred as integers. The size of integer is %d bytes.\n", MSGSIZE / 1024, MSGSIZE / 1024 / 1024, CBSIZE / 1024, sizeofint);
        // printf("Total of %d cycles were required with a number of %d integers transferred, with each cycle having %d integers. \n\n", num_cycles, num_int_total, CBSIZE / 4);
        // printf("%d cycles should have been completed. Check..\n\n", num_cycles);
        printf("\nTime calculated for transfers:\n");
        printf("Since the start-up of processes : %.6lf seconds, \n", finish_time - start_time_init);
        printf("Since the start-up of send      : %.6lf seconds. \n", finish_time - start_time_send);
        printf("\n---\n\n");
        free(arr3);

        /* remove the shared memory object */
        if ((shm_unlink("/littlespoonalltheway") != 0))
            error_prompt("unlink");

        /* close and unlink semaphores */
        if (sem_close(sem1) != 0)
            error_prompt("sem_close1");

        if (sem_unlink(semname1) != 0)
            error_prompt("sem_unlink1");

        if (sem_close(sem2) != 0)
            error_prompt("sem_close2");

        if (sem_unlink(semname2) != 0)
            error_prompt("sem_unlink2");

        break;
    }

    return 0;
}
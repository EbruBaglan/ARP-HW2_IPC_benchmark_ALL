// UNNAMED PIPE
// command line takes KB input,
//
// To run this code ./a.out <size of array>
// Example: $./a.out 1000
//
// To compile & run this code for 100 MB, type following on the terminal
// gcc -Wall -o unnamed unnamed.c && ./unnamed 102400

#define _GNU_SOURCE
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <omp.h>
#include <memory.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>

int flag = 0;

void error_prompt(char error_msg[], int status) //function to prompt the error
{
    if (status < 0)
    {
        perror(error_msg);
        exit(EXIT_FAILURE);
    }
}
// https://stackoverflow.com/questions/3557221/how-do-i-measure-time-in-c/3557272
double what_time_is_it()
{
    struct timespec now;
    clock_gettime(CLOCK_REALTIME, &now);
    return now.tv_sec + now.tv_nsec * 1e-9;
}

void my_handler(int signum)
{
    if (signum == SIGUSR1)
        flag = 1;
}

int main(int argc, char *argv[])
{
    // initiate part---------------------------------------------------
    if (argc < 2)
    {
        perror("Plese input size of array");
        exit(EXIT_FAILURE);
    }
    int res; // for error handling
    int sizeofint = 4; //size of int
    sighandler_t res2; // for error handling
    // int a[atoi(argv[1])]; // create array
    int size_of_array = atoi(argv[1]) * 1024 / sizeof(int); //to find the size of array
    int *a = (int *)malloc(size_of_array * sizeof(int));
    if (a == NULL)
        error_prompt("malloc a failed", -1);

    // assign random number to the array
    for (int i = 0; i < size_of_array; ++i)
    {
        a[i] = rand() % 1000; // modulo by 1000 because for 0-999
        if (i < 3 || i == size_of_array / 2 || i > size_of_array - 4)
            printf("Sent Index%d is %d\n", i, a[i]);
    }
    // fork or exec something here if necessary---------------------------
    double start_time_init = what_time_is_it(); //start counting time including setup
    int p[2];
    if (pipe(p) < 0)
        exit(1);
    int pipesize = fcntl(p[0], F_GETPIPE_SZ);

    int fork_client = fork();
    error_prompt("fork failed", fork_client);
    if (fork_client == 0) //Child process
    {
        res = close(p[1]);
        error_prompt("close(p[1]) failed", res);
        int *buffer = (int *)malloc(size_of_array * sizeof(int));
        if (buffer == NULL)
            error_prompt("malloc buffer failed", -1);
        // fget
        int n = 0;
        int remaining = size_of_array;
        int i = 0;
        while (remaining != 0)
        {
            n += read(p[0], buffer + i, pipesize);
            error_prompt("read failed", n);
            i += pipesize/4;
            res = kill(getppid(), SIGUSR1);
            error_prompt("kill failed", res);
            remaining -= pipesize/4;
            if (remaining < 0)
                remaining = 0;
        }
        printf("---\n");
        printf("Received Index0 is %d\n", buffer[0]);
        printf("Received Index1 is %d\n", buffer[1]);
        printf("Received Index2 is %d\n", buffer[2]);
        printf("Received Index%d is %d\n", size_of_array / 2, buffer[size_of_array / 2]);
        printf("Received Index%d is %d\n", size_of_array - 3, buffer[size_of_array - 3]);
        printf("Received Index%d is %d\n", size_of_array - 2, buffer[size_of_array - 2]);
        printf("Received Index%d is %d\n", size_of_array - 1, buffer[size_of_array - 1]);

        free(buffer);

        res = close(p[0]);
        error_prompt("close(p[0]) failed", res);
        return 0;
    }
    else
    {
        if ((res2 = signal(SIGUSR1, my_handler)) == SIG_ERR)
            error_prompt("kill failed", -1);
        res = close(p[0]);
        error_prompt("close(p[0]) failed", res);
        int remaining = size_of_array;
        int i = 0;
        double start_time_send = what_time_is_it();
        while (remaining != 0)
        {
            res = write(p[1], a + i, pipesize);
            error_prompt("write failed", res);
            i += pipesize/4;
            remaining -= pipesize/4;
            if (remaining < 0)
                remaining = 0;
            while (flag == 0)
                pause();
            flag = 0;
        }
        wait(NULL);
        double finish_time = what_time_is_it();

	res = close(p[1]);
		
	error_prompt("close(p[1]) failed", res);
        printf("---\n\n");
        printf("UNNAMED PIPE\n\n");
        printf("User requested to transfer TOTAL OF %d KB = %d MB with %d KB unnamed pipe capacity.\nData is transferred as integers. The size of integer is %d bytes.\n", atoi(argv[1]), atoi(argv[1]) / 1024, pipesize / 1024, sizeofint);
        printf("\nSo an integer array of %d elements is created and sent successfully.\n", size_of_array);
        printf("\nTime calculated for transfers:\n");
        printf("Since the start-up of processes : %.6lf seconds, \n", finish_time - start_time_init);
        printf("Since the start-up of send      : %.6lf seconds. \n", finish_time - start_time_send);
        printf("\n---\n\n");

        return 0;
    }
}
